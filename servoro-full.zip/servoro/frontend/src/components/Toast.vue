<template>
  <div class="toast-wrapper">
    <div
      v-for="toast in toasts"
      :key="toast.id"
      :class="['toast', toast.type]"
    >
      <component :is="getIcon(toast.type)" class="icon" :size="18" />
      <span class="message">{{ toast.message }}</span>
    </div>
  </div>
</template>

<script setup>
import { reactive } from 'vue'
import { CheckCircle, AlertTriangle, XCircle, Info } from 'lucide-vue-next'

const toasts = reactive([])

function addToast(message, type = 'info', duration = 3000) {
  const id = Date.now() + Math.random()
  toasts.push({ id, message, type })
  setTimeout(() => {
    const index = toasts.findIndex(t => t.id === id)
    if (index !== -1) toasts.splice(index, 1)
  }, duration)
}

function getIcon(type) {
  switch (type) {
    case 'success':
      return CheckCircle
    case 'error':
      return XCircle
    case 'warning':
      return AlertTriangle
    case 'info':
    default:
      return Info
  }
}

defineExpose({ addToast })
</script>

<style scoped>
.toast-wrapper {
  position: fixed;
  top: 20px;
  right: 20px;
  z-index: 9999;
  display: flex;
  flex-direction: column;
  gap: 10px;
  pointer-events: none;
  max-width: 90%;
}

.toast {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 200px;
  max-width: 320px;
  padding: 12px 16px;
  border-radius: 8px;
  font-size: 14px;
  color: white;
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.12);
  pointer-events: all;
  animation: slide-in 0.25s ease-out, fade-out 0.3s ease-in forwards;
  animation-delay: 0s, 2.7s;
}

.toast.success {
  background: #22c55e;
}
.toast.error {
  background: #ef4444;
}
.toast.warning {
  background: #f59e0b;
}
.toast.info {
  background: #3b82f6;
}

.icon {
  flex-shrink: 0;
  color: white;
}

.message {
  flex: 1;
  line-height: 1.4;
}

@keyframes slide-in {
  from {
    transform: translateX(30px);
    opacity: 0;
  }
  to {
    transform: translateX(0);
    opacity: 1;
  }
}

@keyframes fade-out {
  to {
    opacity: 0;
    transform: translateX(30px);
  }
}
</style>