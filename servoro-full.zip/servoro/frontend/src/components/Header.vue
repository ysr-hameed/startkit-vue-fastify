<template>
  <header class="header">
    <div class="left">
      <!-- Mobile menu button -->
      <button class="menu-btn" @click="$emit('toggleMobile')">
        <Menu v-if="!mobileOpen" :size="20" />
        <X v-else :size="20" />
      </button>

      <!-- Logo -->
      <div class="logo">
        <AppWindow :size="22" />
        <span class="logo-text">StartNet</span>
      </div>
    </div>

    <div class="right">
      <button class="icon-btn"><Search :size="18" /></button>

      <!-- Profile Dropdown -->
      <div class="profile" ref="dropdownRef">
        <button class="icon-btn" @click="toggleDropdown">
          <User :size="18" />
        </button>

        <div v-if="dropdownOpen" class="dropdown">
          <router-link to="/profile" @click="closeDropdown">
            <User :size="16" /> Profile
          </router-link>
          <router-link to="/settings" @click="closeDropdown">
            <Settings :size="16" /> Settings
          </router-link>
          <a href="#" @click.prevent="confirmLogout">
            <LogOut :size="16" /> Logout
          </a>
        </div>
      </div>
    </div>

    <!-- Reusable Modal for Logout -->
    <BaseModal
      v-if="showLogoutModal"
      title="Logout"
      confirmText="Yes, Logout"
      cancelText="Cancel"
      @confirm="handleLogout"
      @cancel="showLogoutModal = false"
    >
      <p>Are you sure you want to logout?</p>
    </BaseModal>
  </header>
</template>

<script setup>
import { ref, onMounted, onBeforeUnmount } from 'vue'
import { Menu, X, Search, User, Settings, LogOut, AppWindow } from 'lucide-vue-next'
import BaseModal from '@/components/BaseModal.vue'
import { logout } from '@/api/ProfilePage.js'
defineProps({ mobileOpen: Boolean })

const dropdownOpen = ref(false)
const showLogoutModal = ref(false)
const dropdownRef = ref(null)

const toggleDropdown = () => {
  dropdownOpen.value = !dropdownOpen.value
}

const closeDropdown = () => {
  dropdownOpen.value = false
}

const handleOutsideClick = (e) => {
  if (dropdownRef.value && !dropdownRef.value.contains(e.target)) {
    dropdownOpen.value = false
  }
}

onMounted(() => {
  window.addEventListener('click', handleOutsideClick)
})
onBeforeUnmount(() => {
  window.removeEventListener('click', handleOutsideClick)
})

function confirmLogout() {
  dropdownOpen.value = false
  showLogoutModal.value = true
}



async function handleLogout() {
  try {
    await logout()
    window.location.href = '/login'
  } catch (err) {
    window.$toast(err?.response?.data?.message || 'Logout failed', 'error')
  }
}
</script>

<style scoped>
.header {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 64px;
  background: white;
  border-bottom: 1px solid #eee;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 1rem; /* Mobile default */
  z-index: 1001;
}

/* Desktop: Add more space on left and right */
@media (min-width: 768px) {
  .header {
    padding: 0 2rem; /* or try 2.5rem or 3rem if you want more */
  }
}
.left,
.right {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.menu-btn {
  background: none;
  border: none;
  cursor: pointer;
  padding: 0.5rem;
}

.logo {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-weight: bold;
  color: var(--primary);
}

.logo-text {
  font-size: 1rem;
}

.icon-btn {
  background: none;
  border: none;
  cursor: pointer;
  padding: 0.5rem;
}

.profile {
  position: relative;
}

.dropdown {
  position: absolute;
  top: 120%;
  right: 0;
  background: white;
  border: 1px solid #ddd;
  border-radius: 6px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
  width: 160px;
  z-index: 2000;
  overflow: hidden;
}

.dropdown a,
.dropdown .router-link-active,
.dropdown .router-link-exact-active {
  display: flex;
  align-items: center;
  padding: 0.75rem 1rem;
  color: var(--text);
  text-decoration: none;
  gap: 0.5rem;
}

.dropdown a:hover {
  background: var(--bg-alt);
}

@media (min-width: 768px) {
  .menu-btn {
    display: none;
  }
}
</style>