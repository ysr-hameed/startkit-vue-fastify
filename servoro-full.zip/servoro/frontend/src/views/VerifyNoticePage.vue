<template>
  <div class="login-page">
    <div class="content">
      <h1 class="title">Verify Your Email</h1>
      <p class="sub">
        A verification email has been sent to <strong>{{ email }}</strong>. <br />
        Please check your inbox and click the link to activate your account.
      </p>

      <button class="login-btn" @click="handleResend">
        <span v-if="!loading">Resend Verification Email</span>
        <ButtonLoader v-else :loading="true" />
      </button>

      <div class="signup">
        Already verified? <router-link to="/login">Login here</router-link>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useRoute } from 'vue-router'
import { ref } from 'vue'
import ButtonLoader from '@/components/ButtonLoader.vue'
import axios from 'axios'

const route = useRoute()
const identifier = ref(route.query.email || route.query.username || '')
const loading = ref(false)
const API = import.meta.env.VITE_API_BASE_URL

const handleResend = async () => {
  if (!identifier.value) {
    window.$toast('Email or username is missing', 'error')
    return
  }

  loading.value = true
  try {
    await axios.post(`${API}/resend-verification`, {
      identifier: identifier.value.trim().toLowerCase()
    })
    window.$toast('Verification email resent', 'success')
  } catch (err) {
    const msg = err?.response?.data?.error || 'Unable to resend'
    window.$toast(msg, 'error')
  } finally {
    loading.value = false
  }
}
</script>