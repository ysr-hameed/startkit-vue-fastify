<template>
  <div class="profile-container">
    <div class="profile-card">
      <div class="profile-top">
        <div class="profile-circle">
          {{ initials }}
        </div>
        <div class="profile-name-info">
          <h2>
            {{ user?.first_name }}
            <span v-if="user?.last_name"> {{ user.last_name }}</span>
          </h2>
          <div class="info-item email">
            <Mail class="icon" :size="16" />
            <span>{{ user?.email }}</span>
          </div>
        </div>
      </div>

      <div class="profile-details">
        <p class="username">@{{ user?.username }}</p>
        <div class="profile-actions">
          <button class="icon-btn" @click="showEditModal = true">
            <Pencil :size="15" /> &nbsp;Edit
          </button>
          <button class="icon-btn danger" @click="showLogoutModal = true">
            <LogOut :size="15" />&nbsp; Logout
          </button>
        </div>
      </div>
    </div>

    <!-- Edit Modal -->
    <div v-if="showEditModal" class="modal-overlay">
      <div class="modal">
        <div class="modal-header">
          <h3>Edit Profile</h3>
          <X @click="showEditModal = false" class="close-icon" :size="18" />
        </div>
        <div class="modal-body">
          <div class="input-group">
            <User class="input-icon" :size="16" />
            <input type="text" v-model.trim="form.first_name" placeholder="First Name" />
          </div>
          <div class="input-group">
            <User class="input-icon" :size="16" />
            <input type="text" v-model.trim="form.last_name" placeholder="Last Name (optional)" />
          </div>
          <div class="input-group">
            <User class="input-icon" :size="16" />
            <input type="text" v-model.trim="form.username" placeholder="Username" />
          </div>
        </div>
        <div class="modal-footer">
          <button class="save-btn" @click="submitEdit">Save</button>
        </div>
      </div>
    </div>

    <!-- Logout Modal -->
    <div v-if="showLogoutModal" class="modal-overlay">
      <div class="modal small">
        <div class="modal-header">
          <h3>Logout?</h3>
          <X @click="showLogoutModal = false" class="close-icon" :size="18" />
        </div>
        <div class="modal-body">
          <p>Are you sure you want to logout?</p>
        </div>
        <div class="modal-footer">
          <button class="save-btn" @click="handleLogout">Yes</button>
          <button class="cancel-btn" @click="showLogoutModal = false">No</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import { Mail, User, Pencil, LogOut, X } from 'lucide-vue-next'
import '@/assets/styles/profile.css'

import {
  fetchProfile,
  updateProfile,
  logout,
  checkUsernameAvailable
} from '@/api/ProfilePage.js'

const user = ref(null)
const form = ref({ first_name: '', last_name: '', username: '' })
const showEditModal = ref(false)
const showLogoutModal = ref(false)

const initials = computed(() => {
  if (!user.value) return ''
  const first = user.value.first_name?.[0] || ''
  const last = user.value.last_name?.[0] || ''
  return (first + last).toUpperCase()
})

const loadUser = async () => {
  try {
    const data = await fetchProfile()
    user.value = data
    form.value = { ...data }
  } catch (err) {
    window.$toast('Not logged in', 'error')
  }
}

const submitEdit = async () => {
  const first = form.value.first_name?.trim()
  const last = form.value.last_name?.trim() || ''
  const username = form.value.username?.trim()

  if (!first || !username) {
    return window.$toast('First name and username are required', 'warning')
  }

  if (username !== user.value.username) {
    const available = await checkUsernameAvailable(username)
    if (!available) {
      return window.$toast('Username already taken', 'error')
    }
  }

  try {
    await updateProfile({ first_name: first, last_name: last, username })
    window.$toast('Profile updated', 'success')
    showEditModal.value = false
    loadUser()
  } catch (err) {
    window.$toast(err.message || 'Update failed', 'error')
  }
}

const handleLogout = async () => {
  try {
    await logout()
    window.location.href = '/login'
  } catch (err) {
    window.$toast(err.message || 'Logout failed', 'error')
  }
}

onMounted(loadUser)
</script>