import axios from 'axios'

const API = import.meta.env.VITE_API_BASE_URL

export async function getCurrentUser() {
  const res = await axios.get(`${API}/me`, {
    withCredentials: true // 🔐 include HttpOnly cookie automatically
  })

  return res.data
}