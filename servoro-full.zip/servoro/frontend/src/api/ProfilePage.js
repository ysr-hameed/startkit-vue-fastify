import axios from 'axios'

const API = import.meta.env.VITE_API_BASE_URL

export async function fetchProfile() {
  const res = await axios.get(`${API}/me`, {
    withCredentials: true
  })
  return res.data
}

export async function updateProfile(payload) {
  const res = await axios.put(`${API}/me`, payload, {
    withCredentials: true,
    headers: {
      'Content-Type': 'application/json'
    }
  })
  return res.data
}

export async function checkUsernameAvailable(username) {
  const res = await axios.get(
    `${API}/username-check?username=${encodeURIComponent(username)}`
  )
  return res.data.available
}

export async function logout() {
  await axios.post(`${API}/logout`, {}, {
    withCredentials: true,
    headers: {
      'Content-Type': 'application/json'
    }
  })
}