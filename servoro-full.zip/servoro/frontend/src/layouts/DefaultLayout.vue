<template>
  <div class="layout">
    <!-- Sidebar -->
    <Sidebar
      :collapsed="sidebarCollapsed"
      :mobile="isMobile"
      :open="mobileOpen"
      @toggleCollapse="toggleCollapse"
      @closeMobile="mobileOpen = false"
    />

    <!-- Main Content Area -->
    <div class="main">
      <!-- Header -->
      <Header :mobileOpen="mobileOpen" @toggleMobile="mobileOpen = !mobileOpen" />

      <!-- Page Content Area -->
      <div
        class="page-content"
        :style="{ marginLeft: isMobile ? '0' : sidebarCollapsed ? '75px' : '250px' }"
      >
        <!-- Loader during route change -->
        <div v-if="loading" class="page-loader">
          <div class="spinner" />
        </div>

        <!-- Page content -->
        <router-view v-else />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onBeforeUnmount } from 'vue'
import { useRouter } from 'vue-router'
import Sidebar from '@/components/Sidebar.vue'
import Header from '@/components/Header.vue'

const sidebarCollapsed = ref(true)
const mobileOpen = ref(false)
const isMobile = ref(false)

const toggleCollapse = () => {
  sidebarCollapsed.value = !sidebarCollapsed.value
  localStorage.setItem('sidebar-collapsed', sidebarCollapsed.value)
}

function updateScreenSize() {
  isMobile.value = window.innerWidth < 768
  if (isMobile.value) {
    sidebarCollapsed.value = false
  }
}

onMounted(() => {
  const saved = localStorage.getItem('sidebar-collapsed')
  if (saved !== null) {
    sidebarCollapsed.value = saved === 'true'
  }

  updateScreenSize()
  window.addEventListener('resize', updateScreenSize)
})

onBeforeUnmount(() => {
  window.removeEventListener('resize', updateScreenSize)
})

// 🔄 Page content loader on route change
const loading = ref(false)
const router = useRouter()

router.beforeEach((to, from, next) => {
  loading.value = true
  next()
})
router.afterEach(() => {
  setTimeout(() => {
    loading.value = false
  }, 300)
})
</script>

<style scoped>
.layout {
  display: flex;
  width: calc(100% - 2px);
  padding: 0;
  margin: 0;
  min-height: 100vh;
  overflow-x: hidden;
}

.main {
  width: 100%;
  display: flex;
  flex-direction: column;
  transition: margin-left 0.3s ease;
  padding-top: 64px; /* header height */
  overflow-x: hidden;
}

.page-content {
  flex: 1;
  padding: 1rem;
  min-height: calc(100vh - 64px);
  background: var(--bg);
  color: var(--text);
  position: relative;
  width: 100%;
  transition: padding-left 0.3s ease;
}

.page-loader {
  position: absolute;
  inset: 0;
  background: rgba(255, 255, 255, 0.75);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 10;
}

.spinner {
  width: 32px;
  height: 32px;
  border: 4px solid #ccc;
  border-top-color: var(--primary);
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

/* Mobile fix */
@media (max-width: 767px) {
  .page-content {
    padding-left: 1rem;
    padding-right: 1rem;
    margin-left: 0 !important;
  }
}
</style>

<!-- Prevent scroll leak globally -->
<style>
html, body {
  overflow-x: hidden;
}
</style>