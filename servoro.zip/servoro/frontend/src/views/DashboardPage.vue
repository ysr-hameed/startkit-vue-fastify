<template>
  <section class="dashboard">
    <div v-if="!user">Loading...</div>
    <div v-else>
      <h1>Hello {{ user.username }}</h1>
      <p>Your dashboard is working ✅</p>
    </div>
  </section>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { fetchProfile } from '@/api/ProfilePage'

const user = ref(null)
const route = useRoute()
const router = useRouter()

onMounted(async () => {
  try {
    user.value = await fetchProfile()

    // ✅ Check for OAuth success toast
    if (route.query.oauth === 'success') {
      window.$toast('Successfully logged in via OAuth', 'success')
      router.replace({ path: route.path }) // Remove query param
    }
  } catch (err) {
    console.error('Failed to load profile:', err)
    window.$toast('Failed to load your profile', 'error')
  }
})
</script>