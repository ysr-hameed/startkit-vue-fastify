<template>
  <div class="landing">
    <!-- HEADER -->
    <header class="header">
      <div class="logo">
        <LayoutDashboard class="icon" />
        <span>Servoro</span>
      </div>
      <nav class="nav" :class="{ open: menuOpen }">
        <a href="#features">Features</a>
        <a href="#how">How It Works</a>
        <a href="#stats">Site Stats</a>
        <a href="#contact">Contact</a>
      </nav>
      <div class="menu-icon" @click="toggleMenu">
        <component :is="menuOpen ? X : Menu" class="icon" />
      </div>
    </header>
    <section class="hero">
      <div class="hero-content">
        <h1>Build your startup with real people</h1>
        <p>Your entire SaaS launch stack in one clean platform.</p>
        <button
          v-if="!isLoggedIn"
          class="btn"
          @click="handleGetStarted"
        >
          <Rocket class="icon" />
          Get Started
        </button>
      </div>
    </section>

    <!-- FEATURES -->
    <section id="features" class="features">
      <h2>Everything You Need</h2>
      <div class="features-grid">
        <div class="feature">
          <Zap class="icon-lg" />
          <h3>Fast Deploy</h3>
          <p>Ship in minutes not weeks with zero-config hosting.</p>
        </div>
        <div class="feature">
          <ShieldCheck class="icon-lg" />
          <h3>Secure Auth</h3>
          <p>Cookie-based JWT with social and email login.</p>
        </div>
        <div class="feature">
          <Settings class="icon-lg" />
          <h3>Fully Custom</h3>
          <p>Bring your code, tools, and logic — we scale it.</p>
        </div>
      </div>
    </section>

    <!-- HOW IT WORKS -->
    <section id="how" class="timeline">
      <h2>How It Works</h2>
      <div class="timeline-grid">
        <div class="step">
          <Terminal class="icon" />
          <h3>Connect</h3>
          <p>Auth, database, payments — all connected fast.</p>
        </div>
        <div class="step">
          <Cpu class="icon" />
          <h3>Build</h3>
          <p>Use your framework, our infra.</p>
        </div>
        <div class="step">
          <Upload class="icon" />
          <h3>Launch</h3>
          <p>Push and go live instantly with CI/CD built-in.</p>
        </div>
      </div>
    </section>

    <!-- STATS -->
    <section id="stats" class="stats">
      <h2>Platform Stats</h2>
      <div class="stats-grid">
        <div class="stat">
          <Users class="icon-lg" />
          <h3>{{ stats.users || '–––' }}</h3>
          <p>Total Users</p>
        </div>
        <div class="stat">
          <Rocket class="icon-lg" />
          <h3>{{ stats.startups || '–––' }}</h3>
          <p>Live Startups</p>
        </div>
        <div class="stat">
          <Code2 class="icon-lg" />
          <h3>{{ stats.deploys || '–––' }}</h3>
          <p>Total Deploys</p>
        </div>
      </div>
    </section>

    <!-- CTA -->
    <section class="cta">
      <h2>Ready to launch?</h2>
      <p>Join a growing solo dev movement and build with speed.</p>
      <button class="btn-light" @click="handleGetStarted">
        <UserPlus class="icon" />
        {{ isLoggedIn ? 'Go to Dashboard' : 'Get Started Free' }}
      </button>
    </section>

    <!-- FOOTER -->
    <footer class="footer">
      <div class="footer-top">
        <div class="logo">
          <LayoutDashboard class="icon" />
          <span>StartNet</span>
        </div>
        <div class="footer-links">
          <a href="#">Privacy</a>
          <a href="#">Terms</a>
          <a href="#">Support</a>
        </div>
      </div>
      <div class="footer-bottom">
        <p>© 2025 StartNet. All rights reserved.</p>
      </div>
    </footer>
  </div>
</template>

<script setup>
import {
  LayoutDashboard,
  Rocket,
  UserPlus,
  Zap,
  ShieldCheck,
  Settings,
  Terminal,
  Cpu,
  Upload,
  Users,
  Code2,
  Menu,
  X
} from 'lucide-vue-next'
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import '@/assets/styles/LandingPage.css'

const router = useRouter()
const menuOpen = ref(false)
const isLoggedIn = ref(false)
const stats = ref({})

const toggleMenu = () => {
  menuOpen.value = !menuOpen.value
  document.body.style.overflow = menuOpen.value ? 'hidden' : ''
}

const handleGetStarted = () => {
  if (isLoggedIn.value) {
    router.push('/dashboard')
  } else {
    router.push('/login')
  }
}

onMounted(async () => {
  const user = await getUser()
  isLoggedIn.value = !!user?.email
  stats.value = await getStats()
})
</script>