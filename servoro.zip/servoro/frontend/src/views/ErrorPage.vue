<template>
  <div class="login-page">
    <div class="content">
      <h1 class="title">500 - Internal Server Error</h1>
      <p>Something went wrong. Please try again later.</p>
      <router-link to="/" class="link">Go to Home</router-link>
    </div>
  </div>
</template>

<script setup></script>

<style scoped>
.link {
  color: #007bff;
  text-decoration: underline;
}
</style>