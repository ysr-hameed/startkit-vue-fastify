<template>
  <aside :class="['sidebar', { collapsed, mobile, open }]">
    <!-- Scrollable Nav Section -->
    <div class="scroll-area">
      <nav class="nav">
        <router-link to="/dashboard" @click="handleLinkClick">
          <Home :size="20" />
          <span v-if="!collapsed">Dashboard</span>
        </router-link>

        <router-link to="/profile" @click="handleLinkClick">
          <User :size="20" />
          <span v-if="!collapsed">Profile</span>
        </router-link>

        <router-link to="/billing" @click="handleLinkClick">
          <CreditCard :size="20" />
          <span v-if="!collapsed">Billing</span>
        </router-link>

        <router-link to="/docs" @click="handleLinkClick">
          <BookOpen :size="20" />
          <span v-if="!collapsed">Docs</span>
        </router-link>
      </nav>
    </div>

    <!-- Bottom Footer -->
    <div class="sidebar-footer">
      <button
        v-if="!mobile"
        class="collapse-toggle"
        @click="$emit('toggleCollapse')"
        :title="collapsed ? 'Expand Sidebar' : 'Collapse Sidebar'"
      >
        <ChevronRight v-if="collapsed" :size="20" />
        <ChevronLeft v-else :size="20" />
      </button>

      <button v-if="mobile" class="close-btn" @click="$emit('closeMobile')">
        <X :size="20" />
      </button>
    </div>
  </aside>

  <div v-if="mobile && open" class="backdrop" @click="$emit('closeMobile')"></div>
</template>

<script setup>
import {
  Home,
  Rocket,
  CreditCard,
  BookOpen,
  LogOut,
  User,
  ChevronLeft,
  ChevronRight,
  X
} from 'lucide-vue-next'

const props = defineProps({
  collapsed: Boolean,
  mobile: Boolean,
  open: Boolean
})

function handleLinkClick() {
  if (props.mobile) {
    // Emit close only if mobile
    setTimeout(() => {
      // Slight delay to allow navigation transition
      emit('closeMobile')
    }, 100)
  }
}

const emit = defineEmits(['toggleCollapse', 'closeMobile'])

function logout() {
  localStorage.removeItem('token')
  window.location.href = '/login'
}
</script>
<style scoped>
.sidebar {
  background: white;
  position: fixed;
  top: 64px;
  left: 0;
  height: calc(100vh - 64px);
  z-index: 1000;
  display: flex;
  flex-direction: column;
  transition: width 0.25s ease-in-out;
  overflow: hidden;
  border-right: 1px solid #eee;
  width: 250px;
}
.sidebar.collapsed {
  width: 75px;
}
.scroll-area {
  flex: 1;
  overflow-y: auto;
  padding: 1rem 0.5rem;
}
.nav {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
}
.nav a {
  display: flex;
  align-items: center;
  gap: 1.5rem;
  padding: 0.8rem 1rem;
  color: var(--text);
  text-decoration: none;
  font-weight: 500;
  border-radius: 6px;
  white-space: nowrap;
  transition: background 0.3s, color 0.3s;
}

.nav a:hover {
  background: rgba(0, 0, 0, 0.05);
}

.nav a.router-link-exact-active {
  background: var(--primary);
  color: var(--bg); /* text color = white background */
}

.nav a.router-link-exact-active svg {
  color: var(--bg); /* make icons white too */
}
.sidebar.collapsed .nav a {
  justify-content: center;
  padding: 0.6rem 0;
}
.sidebar.collapsed .nav span {
  display: none;
}
.sidebar-footer {
  border-top: 1px solid #eee;
  padding: 0.75rem;
  display: flex;
  justify-content: flex-end;
  align-items: center;
  flex-shrink: 0;
  background: white;
}
.sidebar.collapsed .sidebar-footer {
  justify-content: center;
}
.collapse-toggle,
.close-btn {
  border: none;
  background: none;
  cursor: pointer;
  padding: 0.5rem;
}
.sidebar.mobile {
  top: 64px;
  height: calc(100vh - 64px);
  width: 250px;
  transform: translateX(-100%);
  transition: transform 0.3s ease;
}
.sidebar.mobile.open {
  transform: translateX(0);
}
@media (max-width: 767px) {
  .sidebar:not(.mobile) {
    display: none;
  }
  .close-btn {
    display: block;
  }
}
.backdrop {
  position: fixed;
  inset: 0;
  overflow-x : hidden;
  background: rgba(0, 0, 0, 0.4);
  z-index: 999;
}
</style>