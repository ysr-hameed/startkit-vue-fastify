<template>
  <span class="dot-loader" v-if="loading">
    <span class="dot"></span>
    <span class="dot"></span>
    <span class="dot"></span>
  </span>
</template>

<script setup>
defineProps({ loading: Boolean })
</script>

<style scoped>
.dot-loader {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  font-size: 1rem;
  padding: 0.75rem 1.5rem;
}

.dot {
  width: 6px;
  height: 6px;
  background-color: #fff; /* Use white for contrast on primary buttons */
  border-radius: 50%;
  animation: blink 1.2s infinite;
  opacity: 0.3;
}

.dot:nth-child(2) {
  animation-delay: 0.2s;
}
.dot:nth-child(3) {
  animation-delay: 0.4s;
}

@keyframes blink {
  0%, 80%, 100% {
    opacity: 0.3;
    transform: scale(0.9);
  }
  40% {
    opacity: 1;
    transform: scale(1);
  }
}
</style>