<template>
  <div class="modal-overlay" @click.self="emitCancel">
    <div class="modal-box">
      <!-- Header -->
      <div class="modal-header">
        <h3 class="modal-title">{{ title }}</h3>
        <X class="close-icon" :size="18" @click="emitCancel" />
      </div>

      <!-- Body (optional) -->
      <div v-if="message || $slots.default" class="modal-body">
        <p v-if="message" class="modal-message">{{ message }}</p>
        <slot />
      </div>

      <!-- Footer -->
      <div class="modal-footer">
        <button v-if="cancelText" class="btn cancel" @click="emitCancel">{{ cancelText }}</button>
        <button v-if="confirmText" class="btn confirm" @click="emitConfirm">{{ confirmText }}</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { X } from 'lucide-vue-next'

defineProps({
  title: String,
  message: String,
  confirmText: String,
  cancelText: String
})

const emit = defineEmits(['confirm', 'cancel'])

const emitConfirm = () => emit('confirm')
const emitCancel = () => emit('cancel')
</script>

<style scoped>
/* Overlay */
.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.4);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

/* Modal Box */
.modal-box {
  background: #fff;
  width: 90%;
  max-width: 380px;
  border-radius: 10px;
  overflow: hidden;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
  animation: fadeIn 0.2s ease;
}

/* Header */
.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.5rem 1rem;
  border-bottom: 1px solid #eee;
  min-height: 48px;
}

.modal-title {
  font-size: 1rem;
  font-weight: 600;
  margin: 0;
  line-height: 1.2;
}

.close-icon {
  cursor: pointer;
  color: #555;
}

/* Body */
.modal-body {
  padding: 0rem 1rem;
}

.modal-message {
  margin: 0;
  line-height: 1.5;
  color: #444;
  font-size: 0.95rem;
}

/* Footer */
.modal-footer {
  padding: 0.6rem 1rem;
  display: flex;
  justify-content: flex-end;
  gap: 0.5rem;
}

.btn {
  padding: 0.7rem 1rem;
  border: none;
  border-radius: 6px;
  font-size: 0.9rem;
  font-weight: 500;
  cursor: pointer;
}

.btn.cancel {
  background: #f3f3f3;
  color: #333;
}

.btn.confirm {
  background: var(--primary);
  color: white;
}

/* Animation */
@keyframes fadeIn {
  from {
    opacity: 0;
    transform: scale(0.97);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}
</style>