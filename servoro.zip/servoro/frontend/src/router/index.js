import { createRouter, createWebHistory } from 'vue-router'
import { getCurrentUser } from '@/api/auth'

// Lazy-loaded views
const Landing = () => import('@/views/LandingPage.vue')
const Dashboard = () => import('@/views/DashboardPage.vue')
const Profile = () => import('@/views/ProfilePage.vue')

const Login = () => import('@/views/LoginPage.vue')
const Register = () => import('@/views/RegisterPage.vue')
const ForgotPassword = () => import('@/views/ForgotPasswordPage.vue')
const ResetPassword = () => import('@/views/ResetPasswordPage.vue')
const VerifyEmail = () => import('@/views/VerifyEmailPage.vue')
const VerifyNotice = () => import('@/views/VerifyNoticePage.vue')
const ResendVerification = () => import('@/views/ResendVerificationPage.vue')

const NotFound = () => import('@/views/NotFoundPage.vue')
const ErrorPage = () => import('@/views/ErrorPage.vue')

const routes = [
  { path: '/', name: 'Landing', component: Landing, meta: { layout: 'public' } },
  { path: '/dashboard', name: 'Dashboard', component: Dashboard, meta: { requiresAuth: true, layout: 'default' } },
  { path: '/profile', name: 'Profile', component: Profile, meta: { requiresAuth: true, layout: 'default' } },

  // Auth routes
  { path: '/login', name: 'Login', component: Login, meta: { layout: 'public' } },
  { path: '/register', name: 'Register', component: Register, meta: { layout: 'public' } },
  { path: '/forgot-password', name: 'ForgotPassword', component: ForgotPassword, meta: { layout: 'public' } },
  { path: '/reset-password', name: 'ResetPassword', component: ResetPassword, meta: { layout: 'public' } },
  { path: '/verify-email', name: 'VerifyEmail', component: VerifyEmail, meta: { layout: 'public' } },
  { path: '/verify-notice', name: 'VerifyNotice', component: VerifyNotice, meta: { layout: 'public' } },
  { path: '/resend-verification', name: 'ResendVerification', component: ResendVerification, meta: { layout: 'public' } },

  // 500 Error route (optional)
  { path: '/error', name: 'ErrorPage', component: ErrorPage, meta: { layout: 'public' } },

  // 404 (must be last)
  { path: '/:catchAll(.*)', name: 'NotFound', component: NotFound, meta: { layout: 'public' } }
]

const router = createRouter({
  history: createWebHistory(),
  routes,
  scrollBehavior: () => ({ top: 0 })
})

// Auth protection
router.beforeEach(async (to, from, next) => {
  document.getElementById('app')?.classList.add('page-loading')

  if (to.meta.requiresAuth) {
    try {
      await getCurrentUser()
      next()
    } catch {
      next('/login')
    }
  } else {
    next()
  }
})

router.afterEach(() => {
  document.getElementById('app')?.classList.remove('page-loading')
})

export default router