<template>
  <div v-if="appLoading" class="startup-loader">
    <!-- Replace this with your own logo or animated SVG if needed -->
    <div class="spinner" />
  </div>

  <component v-else :is="layoutComponent">
    <router-view />
  </component>

  <Toast ref="toastRef" />
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import DefaultLayout from '@/layouts/DefaultLayout.vue'
import Toast from '@/components/Toast.vue'

const route = useRoute()
const toastRef = ref(null)
const appLoading = ref(true)

// Dynamic layout switching
const layoutComponent = computed(() =>
  route.meta.layout === 'default' ? DefaultLayout : 'div'
)

// Show loader only on first app load
onMounted(() => {
  window.$toast = (...args) => toastRef.value?.addToast(...args)

  setTimeout(() => {
    appLoading.value = false
  }, 700) // Show spinner briefly or wait for config/auth session
})
</script>

<style scoped>
.startup-loader {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background: var(--bg, #f9fafb);
}

.spinner {
  width: 38px;
  height: 38px;
  border: 4px solid #ddd;
  border-top-color: var(--primary, #6366f1);
  border-radius: 50%;
  animation: spin 0.9s linear infinite;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
</style>